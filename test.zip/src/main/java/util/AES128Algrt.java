package util;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * AES 加密，解密
 * 
 * @author vlees
 *
 */
public class AES128Algrt {

	private static Logger CurLogger = LoggerFactory.getLogger(AES128Algrt.class);
	private static final String CIPHER_ALGORITHM = "AES/ECB/NoPadding";// "算法/模式/补码方式"
	private static final String CODE = "UTF-8";// 编码格式

	/**
	 * 加密
	 * 
	 * @param sSrc
	 *            加密内容
	 * @param sKey
	 *            密钥
	 * @return
	 * @throws Exception
	 */
	public static String Encrypt(String sSrc, String sKey) throws Exception {
		if (sKey == null) {
			CurLogger.debug("Key为空null");
			return null;
		}
		// 判断Key是否为16位
		if (sKey.length() != 16) {
			CurLogger.debug("Key长度不是16位");
			return null;
		}
		byte[] raw = sKey.getBytes(CODE);
		SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
		Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
		byte[] encrypted = cipher.doFinal(sSrc.getBytes(CODE));

		return Base64Algrt.encode(encrypted);// 此处使用BASE64做转码功能，同时能起到2次加密的作用。
	}

	/**
	 * 解密
	 * 
	 * @param sSrc
	 *            解密内容
	 * @param sKey
	 *            密钥
	 * @return
	 * @throws Exception
	 */
	public static String Decrypt(String sSrc, String sKey) throws Exception {
		try {
			// 判断Key是否正确
			if (sKey == null) {
				CurLogger.debug("Key为空null");
				return null;
			}
			// 判断Key是否为16位
			if (sKey.length() != 16) {
				CurLogger.debug("Key长度不是16位");
				return null;
			}
			byte[] raw = sKey.getBytes(CODE);
			SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES");
			Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
			cipher.init(Cipher.DECRYPT_MODE, skeySpec);
			byte[] encrypted1 = Base64Algrt.decode(sSrc);// 先用base64解密
			try {
				byte[] original = cipher.doFinal(encrypted1);
				String originalString = new String(original, CODE);
				return originalString;
			} catch (Exception e) {
				CurLogger.debug(e.toString());
				return null;
			}
		} catch (Exception ex) {
			CurLogger.debug(ex.toString());
			return null;
		}
	}
}
